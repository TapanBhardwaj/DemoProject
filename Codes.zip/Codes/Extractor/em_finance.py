import codecs
import json
import os
import sys
import urllib

from etk.etk import ETK

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))
from etk.extractors.html_metadata_extractor import HTMLMetadataExtractor
from etk.etk_module import ETKModule
from etk.extractors.glossary_extractor import GlossaryExtractor
from etk.extractors.table_extractor import TableExtractor
import copy


def get_values(row):
    row = row.split(' | ')
    return row


class DemoFinanceETKModule(ETKModule):
    def __init__(self, etk):
        ETKModule.__init__(self, etk)
        self.metadata_extractor = HTMLMetadataExtractor()
        self.table_extractor = TableExtractor()
        self.companies_extractor = GlossaryExtractor(
            self.etk.load_glossary(
                "companies.txt"),
            "countries_extractor",
            self.etk.default_tokenizer,
            case_sensitive=False, ngrams=3)
        self.symbols_extractor = GlossaryExtractor(
            self.etk.load_glossary(
                "symbols.txt"),
            "symbols_extractor",
            self.etk.default_tokenizer,
            case_sensitive=False, ngrams=3)
        self.sectors_extractor = GlossaryExtractor(
            self.etk.load_glossary(
                "sectors.txt"),
            "sectors_extractor",
            self.etk.default_tokenizer,
            case_sensitive=False, ngrams=3)
        self.industries_extractor = GlossaryExtractor(
            self.etk.load_glossary(
                "industries.txt"),
            "industries_extractor",
            self.etk.default_tokenizer,
            case_sensitive=False, ngrams=3)

    def process_document(self, doc):
        """
        Add your code for processing the document
        """

        raw = doc.select_segments("$.raw_content")

        if raw:
            # processing of Parent Doc
            raw = raw[0]
            doc.store(doc.extract(self.table_extractor, raw, return_text=False), "etk2_table")
            description_segments = doc.select_segments(jsonpath='$.etk2_table')
            extracted_tables = description_segments[0].value

            for table in extracted_tables['tables']:
                column_name2id = dict()
                id2column_name = dict()
                docs_row = []
                for id, row in enumerate(table['rows']):
                    txt = row['text']
                    if id == 0:
                        columns = get_values(txt)

                        for idx, col in enumerate(columns):
                            column_name2id[col] = idx
                            id2column_name[idx] = col

                        continue

                    # doc_row = etk.create_document(sample_html, mime_type="text/html", url="http://ex.com/123")
                    temp_dict = copy.deepcopy(doc.cdr_document)

                    if "raw_content" in temp_dict:
                        temp_dict.pop("raw_content")

                    temp_dict['row'] = txt
                    temp_dict['column_name2id'] = column_name2id
                    temp_dict['id2column_name'] = id2column_name

                    if "etk2_table" in temp_dict:
                        temp_dict.pop("etk2_table")

                    doc_row = self.etk.create_document(temp_dict, url=temp_dict['url'] if 'url' in temp_dict else '',
                                                       doc_id=temp_dict['doc_id'] if 'doc_id' in temp_dict else None)

                    docs_row.append(doc_row)

            return docs_row

        else:
            # processing for child docs
            id2column_name = doc.select_segments("$.id2column_name")[0].value
            txt = doc.select_segments("$.row")[0].value

            values = get_values(txt)

            # todo replace print with "doc.kg.add_value" in below if else clauses while running with dig engine
            for idx, value in enumerate(values):
                idx = str(idx)

                if id2column_name[idx] == '52 Week Range' or value == 'N/A':
                    # print(id2column_name[idx], value)
                    continue

                elif id2column_name[idx] == 'Price (Intraday)':
                    ##doc.kg.add_value('Price_Intraday', value=value)
                    print(id2column_name[idx], value)

                elif id2column_name[idx] == '% Change':
                    # doc.kg.add_value('Percent_Change', value=value)
                    print(id2column_name[idx], value)

                elif id2column_name[idx] == 'Avg Vol (3 month)':
                    # doc.kg.add_value('Avg_Volume', value=value)
                    print(id2column_name[idx], value)

                elif id2column_name[idx] == 'Market Cap':
                    ##doc.kg.add_value('Market_Cap', value=value)
                    print(id2column_name[idx], value)

                elif id2column_name[idx] == 'PE Ratio (TTM)':
                    # doc.kg.add_value('PE_Ratio', value=value)
                    print(id2column_name[idx], value)

                else:
                    # doc.kg.add_value(id2column_name[idx], value=value)
                    print(id2column_name[idx], value)

        return list()

    def document_selector(self, doc) -> bool:
        # return doc.cdr_document.get("url").startswith("http://www.ce_news_article.org")
        return True


def get_raw_text(url):
    f = urllib.request.urlopen(url)
    s = f.read().decode("utf-8")
    return s


if __name__ == "__main__":
    sample_html = json.load(codecs.open('sample_html.json', 'r'))  # read sample file from disk

    # sample_html["raw_content"] = get_raw_text("https://finance.yahoo.com/losers?offset=0&count=100")
    # sample_html.pop("raw_content")

    etk = ETK(modules=DemoFinanceETKModule)
    doc = etk.create_document(sample_html, mime_type="text/html", url="http://ex.com/123")

    docs = etk.process_ems(doc)

    for i, result in enumerate(docs):

        if i == 0:
            print("document id", id(result), "cdr id", id(result.cdr_document), "url id",
                  id(result.cdr_document['url']),
                  "doc id", id(result.cdr_document['doc_id']))
        else:

            print("document id", id(result), "cdr id", id(result.cdr_document), "url id",
                  id(result.cdr_document['url']),
                  "row id", id(result.cdr_document['row']), "doc id", id(result.cdr_document['doc_id']))


    print(json.dumps(docs[0].value, indent=2))
